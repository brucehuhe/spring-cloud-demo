this is a demo project show you how to use springboot.

this project use these technologies: freemarker+spring data jpa+hibernate+jdbcTemplate.

this project will show you how to controll exception,how to use cas+shiro to implement a secure management.

