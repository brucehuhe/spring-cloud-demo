package com.hdwang.config;


import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

/**
 * Created by hdwang on 2017/6/19.
 */
@Configuration
@ImportResource("classpath:beans.xml")
public class XmlBean {

}
