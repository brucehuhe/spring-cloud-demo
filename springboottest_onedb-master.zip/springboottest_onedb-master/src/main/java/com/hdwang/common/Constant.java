package com.hdwang.common;

/**
 * Created by hdwang on 2017/6/19.
 * 常量类
 */
public class Constant {

    /**
     * session中用户的key
     */
    public static final String SESSION_USER_KEY = "user";
}
