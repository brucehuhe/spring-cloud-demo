package com.geetest.sdk.java.web.mobiledemo;

/**
 * GeetestWeb配置文件,mobile版本的id与key
 * 
 *
 */
public class GeetestConfig {

	// 填入自己的captcha_id和private_key
	private static final String geetest_id = "7c25da6fe21944cfe507d2f9876775a9";
	private static final String geetest_key = "f5883f4ee3bd4fa8caec67941de1b903";

	public static final String getGeetest_id() {
		return geetest_id;
	}

	public static final String getGeetest_key() {
		return geetest_key;
	}

}
