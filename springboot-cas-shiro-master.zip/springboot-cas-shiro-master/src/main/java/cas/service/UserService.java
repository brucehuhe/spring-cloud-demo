package cas.service;

/**
 * Created by wwu on 2017/4/13.
 */
public interface UserService {
    String getUsername();
}
