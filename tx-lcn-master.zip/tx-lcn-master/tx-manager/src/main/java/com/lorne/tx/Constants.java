package com.lorne.tx;

/**
 * Created by lorne on 2017/6/8.
 */
public class Constants {


    public static int maxConnection;

    public static int socketPort;

    public static String address;

}
