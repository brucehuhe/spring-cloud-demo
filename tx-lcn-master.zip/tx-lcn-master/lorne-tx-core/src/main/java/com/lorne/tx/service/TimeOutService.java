package com.lorne.tx.service;

/**
 * create by lorne on 2017/8/7
 */
public interface TimeOutService {

    void loadOutTime();
}
