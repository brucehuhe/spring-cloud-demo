# lorne-tx-core

lorne-tx-core 是LCN分布式事务框架的切面核心类库