# lorne-tx-core-redis

lorne-tx-core-redis 是LCN分布式事务框架对Redis的扩展支持