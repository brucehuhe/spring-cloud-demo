package com.forezp.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.forezp.service.TestLogService;

@Service
@Component
public class TestLogServiceImpl implements TestLogService {
	
	private Logger log = LoggerFactory.getLogger(TestLogServiceImpl.class);

	@Override
	public String getData() {
		log.info("hello,Bruce!==============");
		return "hello,Bruce";
	}

}
