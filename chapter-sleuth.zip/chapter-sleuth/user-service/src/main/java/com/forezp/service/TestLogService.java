package com.forezp.service;

public interface TestLogService {
	
	public String getData();

}
